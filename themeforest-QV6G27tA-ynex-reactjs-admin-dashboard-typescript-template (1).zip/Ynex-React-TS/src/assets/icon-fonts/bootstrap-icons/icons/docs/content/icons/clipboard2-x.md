---
title: Clipboard2 x
categories:
  - Real world
tags:
  - copy
  - paste
---
