---
title: Check2 circle
categories:
  - UI and keyboard
tags:
  - checkmark
  - todo
  - select
  - done
  - checkbox
---
